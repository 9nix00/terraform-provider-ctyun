package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcGwlbCreateApi
/* 创建网关负载均衡
 */type CtvpcGwlbCreateApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcGwlbCreateApi(client *core.CtyunClient) *CtvpcGwlbCreateApi {
	return &CtvpcGwlbCreateApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/gwlb/create",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcGwlbCreateApi) Do(ctx context.Context, credential core.Credential, req *CtvpcGwlbCreateRequest) (*CtvpcGwlbCreateResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcGwlbCreateResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcGwlbCreateRequest struct {
	RegionID         string  `json:"regionID,omitempty"`         /*  区域ID  */
	ClientToken      string  `json:"clientToken,omitempty"`      /*  客户端存根，用于保证订单幂等性。要求单个云平台账户内唯一  */
	ProjectID        *string `json:"projectID,omitempty"`        /*  企业项目ID，默认"0"  */
	SubnetID         string  `json:"subnetID,omitempty"`         /*  子网 ID  */
	Name             string  `json:"name,omitempty"`             /*  支持拉丁字母、中文、数字，下划线，连字符，中文 / 英文字母开头，不能以 http: / https: 开头，长度 2 - 32  */
	PrivateIpAddress *string `json:"privateIpAddress,omitempty"` /*  私有 ip 地址  */
	Ipv6Address      *string `json:"ipv6Address,omitempty"`      /*  ipv6 地址  */
	DeleteProtection *bool   `json:"deleteProtection"`           /*  是否开启删除保护，默认为 False  */
	Ipv6Enabled      *bool   `json:"ipv6Enabled"`                /*  是否开启 ipv6，默认为 False  */
	CycleType        string  `json:"cycleType,omitempty"`        /*  仅支持按需  */
	PayVoucherPrice  *string `json:"payVoucherPrice,omitempty"`  /*  代金券金额，支持到小数点后两位  */
}

type CtvpcGwlbCreateResponse struct {
	StatusCode  int32                             `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                           `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                           `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                           `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   *CtvpcGwlbCreateReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
}

type CtvpcGwlbCreateReturnObjResponse struct {
	MasterOrderID        *string `json:"masterOrderID,omitempty"`        /*  订单id。  */
	MasterOrderNO        *string `json:"masterOrderNO,omitempty"`        /*  订单编号, 可以为 null。  */
	MasterResourceStatus *string `json:"masterResourceStatus,omitempty"` /*  资源状态: started（启用） / renewed（续订） / refunded（退订） / destroyed（销毁） / failed（失败） / starting（正在启用） / changed（变配）/ expired（过期）/ unknown（未知）  */
	MasterResourceID     *string `json:"masterResourceID,omitempty"`     /*  资源 ID 可以为 null。  */
	RegionID             *string `json:"regionID,omitempty"`             /*  可用区id。  */
	GwLbID               *string `json:"gwLbID,omitempty"`               /*  网关负载均衡 ID  */
}

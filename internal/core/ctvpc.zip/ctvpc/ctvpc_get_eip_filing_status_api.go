package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcGetEipFilingStatusApi
/* 获取EIP端口备案状态。
 */type CtvpcGetEipFilingStatusApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcGetEipFilingStatusApi(client *core.CtyunClient) *CtvpcGetEipFilingStatusApi {
	return &CtvpcGetEipFilingStatusApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodGet,
			UrlPath:      "/v4/eip/get-filing-status",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcGetEipFilingStatusApi) Do(ctx context.Context, credential core.Credential, req *CtvpcGetEipFilingStatusRequest) (*CtvpcGetEipFilingStatusResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	ctReq.AddParam("regionID", req.RegionID)
	ctReq.AddParam("eipID", req.EipID)
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcGetEipFilingStatusResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcGetEipFilingStatusRequest struct {
	RegionID string /*  资源池 ID  */
	EipID    string /*  弹性公网IP的ID  */
}

type CtvpcGetEipFilingStatusResponse struct {
	StatusCode  int32                                       `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                                     `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                                     `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                                     `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   []*CtvpcGetEipFilingStatusReturnObjResponse `json:"returnObj"`             /*  object  */
	Error       *string                                     `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcGetEipFilingStatusReturnObjResponse struct {
	AccessControl *bool `json:"accessControl"` /*  端口备案状态, true表示开启, false 表示关闭  */
}

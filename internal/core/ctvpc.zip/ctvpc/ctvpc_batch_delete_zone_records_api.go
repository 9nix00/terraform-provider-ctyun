package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcBatchDeleteZoneRecordsApi
/* 内网 DNS 记录集批量删除
 */type CtvpcBatchDeleteZoneRecordsApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcBatchDeleteZoneRecordsApi(client *core.CtyunClient) *CtvpcBatchDeleteZoneRecordsApi {
	return &CtvpcBatchDeleteZoneRecordsApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/private-zone-record/batch-delete",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcBatchDeleteZoneRecordsApi) Do(ctx context.Context, credential core.Credential, req *CtvpcBatchDeleteZoneRecordsRequest) (*CtvpcBatchDeleteZoneRecordsResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcBatchDeleteZoneRecordsResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcBatchDeleteZoneRecordsRequest struct {
	ClientToken   string   `json:"clientToken,omitempty"` /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID      string   `json:"regionID,omitempty"`    /*  资源池ID  */
	ZoneRecordIDs []string `json:"zoneRecordIDs"`         /*  zoneRecordID, 最多支持 10 个记录同时删除  */
}

type CtvpcBatchDeleteZoneRecordsResponse struct {
	StatusCode  int32   `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	Error       *string `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

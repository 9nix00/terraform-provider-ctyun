package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcListPrivateZoneRecordApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcListPrivateZoneRecordApi

	// 构造请求
	var zoneRecordName string = ""
	var zoneID string = "zone-r5i4zghgvq"
	var zoneRecordID string = "zr-05ksm4lInteger"
	request := &CtvpcListPrivateZoneRecordRequest{
		RegionID:       "",
		ZoneRecordName: &zoneRecordName,
		ZoneID:         &zoneID,
		ZoneRecordID:   &zoneRecordID,
		PageNumber:     1,
		PageNo:         1,
		PageSize:       5,
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

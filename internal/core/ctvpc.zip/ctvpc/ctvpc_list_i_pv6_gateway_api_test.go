package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcListIPv6GatewayApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcListIPv6GatewayApi

	// 构造请求
	var projectID string = "0"
	request := &CtvpcListIPv6GatewayRequest{
		ProjectID:  &projectID,
		PageNumber: 1,
		PageNo:     1,
		PageSize:   5,
		RegionID:   "xj8g-894g-09oi-po09-12ol-6e6a",
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

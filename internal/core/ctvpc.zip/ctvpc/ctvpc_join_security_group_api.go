package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcJoinSecurityGroupApi
/* 绑定安全组。
 */type CtvpcJoinSecurityGroupApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcJoinSecurityGroupApi(client *core.CtyunClient) *CtvpcJoinSecurityGroupApi {
	return &CtvpcJoinSecurityGroupApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/vpc/join-security-group",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcJoinSecurityGroupApi) Do(ctx context.Context, credential core.Credential, req *CtvpcJoinSecurityGroupRequest) (*CtvpcJoinSecurityGroupResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcJoinSecurityGroupResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcJoinSecurityGroupRequest struct {
	RegionID           string  `json:"regionID,omitempty"`           /*  区域id  */
	SecurityGroupID    string  `json:"securityGroupID,omitempty"`    /*  安全组ID  */
	InstanceID         string  `json:"instanceID,omitempty"`         /*  实例ID。  */
	NetworkInterfaceID *string `json:"networkInterfaceID,omitempty"` /*  弹性网卡ID。  */
	Action             string  `json:"action,omitempty"`             /*  系统规定参数  */
}

type CtvpcJoinSecurityGroupResponse struct {
	StatusCode  int32   `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

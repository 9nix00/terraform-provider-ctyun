package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcIplistenerUpdateApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcIplistenerUpdateApi

	// 构造请求
	var name string = "acl11"
	var targetGroupID string = ""
	request := &CtvpcIplistenerUpdateRequest{
		RegionID:      "bb9fdb42056f11eda1610242ac110002",
		IpListenerID:  "",
		Name:          &name,
		TargetGroupID: &targetGroupID,
		Weight:        0,
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

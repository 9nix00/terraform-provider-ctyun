package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcCreateAclApi
/* 创建 Acl
 */type CtvpcCreateAclApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcCreateAclApi(client *core.CtyunClient) *CtvpcCreateAclApi {
	return &CtvpcCreateAclApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/acl/create",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcCreateAclApi) Do(ctx context.Context, credential core.Credential, req *CtvpcCreateAclRequest) (*CtvpcCreateAclResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcCreateAclResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcCreateAclRequest struct {
	ClientToken string  `json:"clientToken,omitempty"` /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID    string  `json:"regionID,omitempty"`    /*  资源池ID  */
	ProjectID   *string `json:"projectID,omitempty"`   /*  企业项目 ID，默认为'0'  */
	VpcID       string  `json:"vpcID,omitempty"`       /*  关联的vpc  */
	Name        string  `json:"name,omitempty"`        /*  支持拉丁字母、中文、数字，下划线，连字符，中文 / 英文字母开头，不能以 http: / https: 开头，长度 2 - 32  */
}

type CtvpcCreateAclResponse struct {
	StatusCode  int32                              `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                            `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                            `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                            `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   []*CtvpcCreateAclReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
	Error       *string                            `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcCreateAclReturnObjResponse struct {
	AclID *string `json:"aclID,omitempty"` /*  acl id  */
	Name  *string `json:"name,omitempty"`  /*  acl 名称  */
}

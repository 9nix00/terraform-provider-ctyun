package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcModifyIPv6BandwidthSpecApi
/* 修改 IPv6 带宽规格。
 */type CtvpcModifyIPv6BandwidthSpecApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcModifyIPv6BandwidthSpecApi(client *core.CtyunClient) *CtvpcModifyIPv6BandwidthSpecApi {
	return &CtvpcModifyIPv6BandwidthSpecApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/ipv6_bandwidth/modify-spec",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcModifyIPv6BandwidthSpecApi) Do(ctx context.Context, credential core.Credential, req *CtvpcModifyIPv6BandwidthSpecRequest) (*CtvpcModifyIPv6BandwidthSpecResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcModifyIPv6BandwidthSpecResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcModifyIPv6BandwidthSpecRequest struct {
	ClientToken     string  `json:"clientToken,omitempty"`     /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID        string  `json:"regionID,omitempty"`        /*  共享带宽的区域id。  */
	BandwidthID     string  `json:"bandwidthID,omitempty"`     /*  共享带宽id。  */
	Bandwidth       int32   `json:"bandwidth"`                 /*  共享带宽的带宽峰值。范围1-1000  */
	PayVoucherPrice *string `json:"payVoucherPrice,omitempty"` /*  代金券金额，支持到小数点后两位  */
}

type CtvpcModifyIPv6BandwidthSpecResponse struct {
	StatusCode  int32                                            `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                                          `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                                          `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                                          `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   []*CtvpcModifyIPv6BandwidthSpecReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
	Error       *string                                          `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcModifyIPv6BandwidthSpecReturnObjResponse struct {
	MasterOrderID *string `json:"masterOrderID,omitempty"` /*  订单id。  */
	MasterOrderNO *string `json:"masterOrderNO,omitempty"` /*  订单编号, 可以为 null。  */
	RegionID      *string `json:"regionID,omitempty"`      /*  可用区id。  */
}

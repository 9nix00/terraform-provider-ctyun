package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcCreatePrivateZoneApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcCreatePrivateZoneApi

	// 构造请求
	var proxyPattern string = "zone"
	request := &CtvpcCreatePrivateZoneRequest{
		ClientToken:  "79fa97e3-c48b-xxxx-9f46-6a13d8163678",
		RegionID:     "",
		VpcIDList:    "vpc-tuid8d646e, vpc-tuid8d646e",
		Name:         "a.b",
		ProxyPattern: &proxyPattern,
		TTL:          300,
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

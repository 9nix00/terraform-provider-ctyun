package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcCreateIPv6BandwidthApi
/* 创建 IPv6 带宽。
 */type CtvpcCreateIPv6BandwidthApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcCreateIPv6BandwidthApi(client *core.CtyunClient) *CtvpcCreateIPv6BandwidthApi {
	return &CtvpcCreateIPv6BandwidthApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/ipv6_bandwidth/create",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcCreateIPv6BandwidthApi) Do(ctx context.Context, credential core.Credential, req *CtvpcCreateIPv6BandwidthRequest) (*CtvpcCreateIPv6BandwidthResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcCreateIPv6BandwidthResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcCreateIPv6BandwidthRequest struct {
	ClientToken     string  `json:"clientToken,omitempty"`     /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID        string  `json:"regionID,omitempty"`        /*  创建共享带宽的区域id。  */
	Bandwidth       int32   `json:"bandwidth"`                 /*  共享带宽的带宽峰值，输入限制1-1000，如果不传默认是 1。  */
	CycleType       string  `json:"cycleType,omitempty"`       /*  仅支持订购类型：包年/包月订购。<br>month / year  */
	CycleCount      int32   `json:"cycleCount"`                /*  购时长, 当 cycleType = month, 支持续订 1 - 11 个月; 当 cycleType = year, 支持续订 1 - 3 年  */
	Name            string  `json:"name,omitempty"`            /*  支持拉丁字母、中文、数字，下划线，连字符，中文 / 英文字母开头，不能以 http: / https: 开头，长度 2 - 32  */
	PayVoucherPrice *string `json:"payVoucherPrice,omitempty"` /*  代金券金额，支持到小数点后两位  */
}

type CtvpcCreateIPv6BandwidthResponse struct {
	StatusCode  int32                                        `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                                      `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                                      `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                                      `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   []*CtvpcCreateIPv6BandwidthReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
	Error       *string                                      `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcCreateIPv6BandwidthReturnObjResponse struct {
	MasterOrderID        *string `json:"masterOrderID,omitempty"`        /*  订单id。  */
	MasterOrderNO        *string `json:"masterOrderNO,omitempty"`        /*  订单编号, 可以为 null。  */
	MasterResourceStatus *string `json:"masterResourceStatus,omitempty"` /*  资源状态: started（启用） / renewed（续订） / refunded（退订） / destroyed（销毁） / failed（失败） / starting（正在启用） / changed（变配）/ expired（过期）/ unknown（未知）  */
	MasterResourceID     *string `json:"masterResourceID,omitempty"`     /*  资源 ID 可以为 null。  */
	RegionID             *string `json:"regionID,omitempty"`             /*  可用区id。  */
	BandwidthID          *string `json:"bandwidthID,omitempty"`          /*  带宽 ID  */
}

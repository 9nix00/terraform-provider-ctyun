package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcIplistenerShowApi
/* 查看ip_listener详情
 */type CtvpcIplistenerShowApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcIplistenerShowApi(client *core.CtyunClient) *CtvpcIplistenerShowApi {
	return &CtvpcIplistenerShowApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodGet,
			UrlPath:      "/v4/iplistener/show",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcIplistenerShowApi) Do(ctx context.Context, credential core.Credential, req *CtvpcIplistenerShowRequest) (*CtvpcIplistenerShowResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	ctReq.AddParam("regionID", req.RegionID)
	ctReq.AddParam("ipListenerID", req.IpListenerID)
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcIplistenerShowResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcIplistenerShowRequest struct {
	RegionID     string /*  资源池 ID  */
	IpListenerID string /*  监听器 ID  */
}

type CtvpcIplistenerShowResponse struct {
	StatusCode  int32                                 `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                               `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                               `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                               `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   *CtvpcIplistenerShowReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
}

type CtvpcIplistenerShowReturnObjResponse struct {
	GwElbID      *string                                     `json:"gwElbID,omitempty"`      /*  网关负载均衡 ID  */
	Name         *string                                     `json:"name,omitempty"`         /*  名字  */
	Description  *string                                     `json:"description,omitempty"`  /*  描述  */
	IpListenerID *string                                     `json:"ipListenerID,omitempty"` /*  监听器 id  */
	Action       *CtvpcIplistenerShowReturnObjActionResponse `json:"action"`                 /*  转发配置  */
}

type CtvpcIplistenerShowReturnObjActionResponse struct {
	RawType       *string                                                  `json:"type,omitempty"` /*  默认规则动作类型: forward / redirect  */
	ForwardConfig *CtvpcIplistenerShowReturnObjActionForwardConfigResponse `json:"forwardConfig"`  /*  转发配置  */
}

type CtvpcIplistenerShowReturnObjActionForwardConfigResponse struct {
	TargetGroups []*CtvpcIplistenerShowReturnObjActionForwardConfigTargetGroupsResponse `json:"targetGroups"` /*  后端服务组  */
}

type CtvpcIplistenerShowReturnObjActionForwardConfigTargetGroupsResponse struct {
	TargetGroupID *string `json:"targetGroupID,omitempty"` /*  后端服务组ID  */
	Weight        int32   `json:"weight"`                  /*  权重  */
}

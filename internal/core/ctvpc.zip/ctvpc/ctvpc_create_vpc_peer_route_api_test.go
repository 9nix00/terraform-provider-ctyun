package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcCreateVpcPeerRouteApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcCreateVpcPeerRouteApi

	// 构造请求
	request := &CtvpcCreateVpcPeerRouteRequest{
		IpVersion:   4,
		NextHopID:   "",
		VpcID:       "vpc-101c",
		Destination: "192.168.1.0/24",
		RegionID:    "81f7728662dd11ec810800155d307d5b",
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcAddVpcAccessLogApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcAddVpcAccessLogApi

	// 构造请求
	var clientToken string = "79fa97e3-c48b-xxxx-9f46-6a13d8163678"
	var projectID string = ""
	var description string = ""
	request := &CtvpcAddVpcAccessLogRequest{
		ClientToken:    &clientToken,
		RegionID:       "",
		Name:           "",
		ResourceID:     "",
		ResourceType:   "",
		FlowType:       0,
		LogProjectCode: "",
		LogUnitCode:    "",
		LogCollection:  0,
		SampleInterval: 0,
		ProjectID:      &projectID,
		Description:    &description,
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

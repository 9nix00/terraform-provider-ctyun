package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcCheckZoneNameApi
/* 检查 zone name 是否冲突和合法
 */type CtvpcCheckZoneNameApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcCheckZoneNameApi(client *core.CtyunClient) *CtvpcCheckZoneNameApi {
	return &CtvpcCheckZoneNameApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/private-zone/check-name",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcCheckZoneNameApi) Do(ctx context.Context, credential core.Credential, req *CtvpcCheckZoneNameRequest) (*CtvpcCheckZoneNameResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcCheckZoneNameResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcCheckZoneNameRequest struct {
	RegionID string `json:"regionID,omitempty"` /*  资源池ID  */
	ZoneName string `json:"zoneName,omitempty"` /*  待检查 zone name  */
}

type CtvpcCheckZoneNameResponse struct {
	StatusCode  int32                                `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                              `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                              `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                              `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   *CtvpcCheckZoneNameReturnObjResponse `json:"returnObj"`             /*  检查结果  */
	Error       *string                              `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcCheckZoneNameReturnObjResponse struct {
	Valid   *bool   `json:"valid"`             /*  是否合法  */
	Message *string `json:"message,omitempty"` /*  提示信息  */
}

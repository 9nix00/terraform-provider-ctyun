package ctvpc

import (
	"context"
	"net/http"
	"strconv"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcIplistenerListApi
/* 查看ip_listener列表
 */type CtvpcIplistenerListApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcIplistenerListApi(client *core.CtyunClient) *CtvpcIplistenerListApi {
	return &CtvpcIplistenerListApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodGet,
			UrlPath:      "/v4/iplistener/list",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcIplistenerListApi) Do(ctx context.Context, credential core.Credential, req *CtvpcIplistenerListRequest) (*CtvpcIplistenerListResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	ctReq.AddParam("regionID", req.RegionID)
	if req.IpListenerID != nil {
		ctReq.AddParam("ipListenerID", *req.IpListenerID)
	}
	if req.PageNumber != 0 {
		ctReq.AddParam("pageNumber", strconv.FormatInt(int64(req.PageNumber), 10))
	}
	if req.PageSize != 0 {
		ctReq.AddParam("pageSize", strconv.FormatInt(int64(req.PageSize), 10))
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcIplistenerListResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcIplistenerListRequest struct {
	RegionID     string  /*  资源池 ID  */
	IpListenerID *string /*  监听器 ID  */
	PageNumber   int32   /*  列表的页码，默认值为 1。  */
	PageSize     int32   /*  分页查询时每页的行数，最大值为 50，默认值为 10。  */
}

type CtvpcIplistenerListResponse struct {
	StatusCode  int32                                 `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                               `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                               `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                               `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   *CtvpcIplistenerListReturnObjResponse `json:"returnObj"`             /*  接口业务数据  */
}

type CtvpcIplistenerListReturnObjResponse struct {
	Results      []*CtvpcIplistenerListReturnObjResultsResponse `json:"results"`      /*  接口业务数据  */
	TotalCount   int32                                          `json:"totalCount"`   /*  列表条目数  */
	CurrentCount int32                                          `json:"currentCount"` /*  分页查询时每页的行数。  */
	TotalPage    int32                                          `json:"totalPage"`    /*  总页数  */
}

type CtvpcIplistenerListReturnObjResultsResponse struct {
	GwElbID      *string                                            `json:"gwElbID,omitempty"`      /*  网关负载均衡 ID  */
	Name         *string                                            `json:"name,omitempty"`         /*  名字  */
	Description  *string                                            `json:"description,omitempty"`  /*  描述  */
	IpListenerID *string                                            `json:"ipListenerID,omitempty"` /*  监听器 id  */
	Action       *CtvpcIplistenerListReturnObjResultsActionResponse `json:"action"`                 /*  转发配置  */
}

type CtvpcIplistenerListReturnObjResultsActionResponse struct {
	RawType       *string                                                         `json:"type,omitempty"` /*  默认规则动作类型: forward / redirect  */
	ForwardConfig *CtvpcIplistenerListReturnObjResultsActionForwardConfigResponse `json:"forwardConfig"`  /*  转发配置  */
}

type CtvpcIplistenerListReturnObjResultsActionForwardConfigResponse struct{}

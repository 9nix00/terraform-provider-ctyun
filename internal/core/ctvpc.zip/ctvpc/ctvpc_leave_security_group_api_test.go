package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcLeaveSecurityGroupApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcLeaveSecurityGroupApi

	// 构造请求
	request := &CtvpcLeaveSecurityGroupRequest{
		SecurityGroupID: "sg-bp67axxxxzb4p",
		RegionID:        "79fa97e3-c48b-xxxx-9f46-6a13d8163678",
		InstanceID:      "89a2d977-c078-5779-f391-f0ab8c9773b6",
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcAssignSecondaryPrivateIPsToPortApi
/* 网卡关联辅助私网IP
 */type CtvpcAssignSecondaryPrivateIPsToPortApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcAssignSecondaryPrivateIPsToPortApi(client *core.CtyunClient) *CtvpcAssignSecondaryPrivateIPsToPortApi {
	return &CtvpcAssignSecondaryPrivateIPsToPortApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/ports/assign-secondary-private-ips",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcAssignSecondaryPrivateIPsToPortApi) Do(ctx context.Context, credential core.Credential, req *CtvpcAssignSecondaryPrivateIPsToPortRequest) (*CtvpcAssignSecondaryPrivateIPsToPortResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcAssignSecondaryPrivateIPsToPortResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcAssignSecondaryPrivateIPsToPortRequest struct {
	ClientToken             string    `json:"clientToken,omitempty"`        /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID                string    `json:"regionID,omitempty"`           /*  资源池ID  */
	NetworkInterfaceID      string    `json:"networkInterfaceID,omitempty"` /*  弹性网卡ID  */
	SecondaryPrivateIps     []*string `json:"secondaryPrivateIps"`          /*  辅助私网IP列表，新增辅助私网IP, 最多支持 15 个  */
	SecondaryPrivateIpCount int32     `json:"secondaryPrivateIpCount"`      /*  辅助私网IP数量，新增自动分配辅助私网IP的数量, 最多支持 15 个  */
}

type CtvpcAssignSecondaryPrivateIPsToPortResponse struct {
	StatusCode  int32                                                  `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string                                                `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string                                                `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string                                                `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	ReturnObj   *CtvpcAssignSecondaryPrivateIPsToPortReturnObjResponse `json:"returnObj"`             /*  业务数据  */
	Error       *string                                                `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

type CtvpcAssignSecondaryPrivateIPsToPortReturnObjResponse struct {
	SecondaryPrivateIps []*string `json:"secondaryPrivateIps"` /*  分配的私网 ip 地址  */
}

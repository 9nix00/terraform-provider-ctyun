package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcCreateEndpointServiceRuleApi
/* 终端节点服务端口映射创建接口
 */type CtvpcCreateEndpointServiceRuleApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcCreateEndpointServiceRuleApi(client *core.CtyunClient) *CtvpcCreateEndpointServiceRuleApi {
	return &CtvpcCreateEndpointServiceRuleApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/vpce/create-endpoint-service-rule",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcCreateEndpointServiceRuleApi) Do(ctx context.Context, credential core.Credential, req *CtvpcCreateEndpointServiceRuleRequest) (*CtvpcCreateEndpointServiceRuleResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcCreateEndpointServiceRuleResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcCreateEndpointServiceRuleRequest struct {
	ClientToken       string `json:"clientToken,omitempty"`       /*  客户端存根，用于保证订单幂等性, 长度 1 - 64  */
	RegionID          string `json:"regionID,omitempty"`          /*  资源池ID  */
	EndpointServiceID string `json:"endpointServiceID,omitempty"` /*  终端节点关联的终端节点服务  */
	Protocol          string `json:"protocol,omitempty"`          /*  TCP:TCP协议,UDP:UDP协议  */
	ServerPort        int32  `json:"serverPort"`                  /*  服务端口(1-65535)  */
	EndpointPort      int32  `json:"endpointPort"`                /*  节点端口(1-65535)  */
}

type CtvpcCreateEndpointServiceRuleResponse struct {
	StatusCode  int32   `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success, 英文  */
	Description *string `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功, 中文  */
	ErrorCode   *string `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	Error       *string `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}

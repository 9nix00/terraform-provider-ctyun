package ctvpc

import (
	"context"
	"terraform-provider-ctyun/internal/core/core"
	"testing"
)

func TestCtvpcL2gwUpdateApi_Do(t *testing.T) {
	// 初始化
	client := core.DefaultClient()
	credential := core.NewCredential("<YOUR_AK>", "<YOUR_SK>")
	// credential := core.CredentialFromEnv()
	apis := NewApis("<YOUR_ENDPOINT>", client)
	api := apis.CtvpcL2gwUpdateApi

	// 构造请求
	var description string = ""
	request := &CtvpcL2gwUpdateRequest{
		RegionID:    "",
		L2gwID:      "l2gw-hfw53u96ku",
		Name:        "l2gw11",
		Description: &description,
	}

	// 发起调用
	response, err := api.Do(context.Background(), *credential, request)
	if err != nil {
		t.Log("request error:", err)
		t.Fail()
		return
	}
	t.Logf("%+v\n", *response)
}

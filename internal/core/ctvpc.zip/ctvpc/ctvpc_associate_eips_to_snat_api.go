package ctvpc

import (
	"context"
	"net/http"
	"terraform-provider-ctyun/internal/core/core"
)

// CtvpcAssociateEipsToSnatApi
/* SNAT 添加 EIP
 */type CtvpcAssociateEipsToSnatApi struct {
	template core.CtyunRequestTemplate
	client   *core.CtyunClient
}

func NewCtvpcAssociateEipsToSnatApi(client *core.CtyunClient) *CtvpcAssociateEipsToSnatApi {
	return &CtvpcAssociateEipsToSnatApi{
		client: client,
		template: core.CtyunRequestTemplate{
			EndpointName: EndpointName,
			Method:       http.MethodPost,
			UrlPath:      "/v4/vpc/join-snat-for-eips",
			ContentType:  "application/json",
		},
	}
}

func (a *CtvpcAssociateEipsToSnatApi) Do(ctx context.Context, credential core.Credential, req *CtvpcAssociateEipsToSnatRequest) (*CtvpcAssociateEipsToSnatResponse, error) {
	builder := core.NewCtyunRequestBuilder(a.template)
	builder.WithCredential(credential)
	ctReq := builder.Build()
	_, err := ctReq.WriteJson(req, a.template.ContentType)
	if err != nil {
		return nil, err
	}
	response, err := a.client.RequestToEndpoint(ctx, ctReq)
	if err != nil {
		return nil, err
	}
	var resp CtvpcAssociateEipsToSnatResponse
	err = response.Parse(&resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}

type CtvpcAssociateEipsToSnatRequest struct {
	RegionID     string   `json:"regionID,omitempty"`     /*  区域id  */
	NatGatewayID string   `json:"natGatewayID,omitempty"` /*  NAT网关ID  */
	SNatID       string   `json:"sNatID,omitempty"`       /*  SNAT条目所在的SNAT表的ID。  */
	IpAddressIds []string `json:"ipAddressIds"`           /*  弹性公网IP集合  */
	ClientToken  string   `json:"clientToken,omitempty"`  /*  客户端存根，用于保证订单幂等性， 长度 1 - 64  */
}

type CtvpcAssociateEipsToSnatResponse struct {
	StatusCode  int32   `json:"statusCode"`            /*  返回状态码（800为成功，900为失败）  */
	Message     *string `json:"message,omitempty"`     /*  statusCode为900时的错误信息; statusCode为800时为success， 英文  */
	Description *string `json:"description,omitempty"` /*  statusCode为900时的错误信息; statusCode为800时为成功， 中文  */
	ErrorCode   *string `json:"errorCode,omitempty"`   /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
	Error       *string `json:"error,omitempty"`       /*  statusCode为900时为业务细分错误码，三段式：product.module.code; statusCode为800时为SUCCESS  */
}
